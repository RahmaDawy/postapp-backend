 import Joi from "joi";
 
 
 export const validation=(schema)=>{
    return (req,res,next)=>{
        const{error}=schema.validate(req.body,{abortEarly:false});
  if(error){
    res.json(error.details.map((err)=>err.message));
  }else{
    next()
  }
    }
 }