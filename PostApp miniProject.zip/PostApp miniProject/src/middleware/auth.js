import jwt from "jsonwebtoken"
export const verifyToken=(req,res,next)=>{
    const token=req.headers["token"];
    console.log("Received Token:", token);
jwt.verify(token,"rahmadassemdawi",async function (err,decoded){

    if(err){
        res.json({message:"ERROR in token",err})
    }
    else{
        req.userID=decoded.userID
        console.log(decoded)
        next()
    }
})
}
