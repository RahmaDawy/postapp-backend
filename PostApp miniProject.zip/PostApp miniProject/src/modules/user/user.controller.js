import { userModel } from "../../../database/models/user.model.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken"
import { signInSchema, signUpSchema } from "./user.validation.js";

export const signup = async (req, res) => {
  const { name, email, password } = req.body;
 
    let user = await userModel.findOne({ email });
    if (user) {
      res.json({ message: "user already in use" });
    } else {
      bcrypt.hash(password, 8, async function (err, hash) {
        await userModel.insertMany({ name, email, password: hash });
      });
      res.json({ message:  "Account created successfully!" });
    }
  }
 
export const signin = async (req, res) => {
  const { email, password } = req.body;
  
    const user = await userModel.findOne({ email });

    if (!user) {
      return res.json({ message: "user not found" });
    }
  
    const match = await bcrypt.compare(password, user.password);
  
    if (!match) {
      return res.json({ message: "incorrect password" });
    
  
    // Only sign the token after confirming the password
    const token = jwt.sign({
      name: user.name,
      email: user.email,
      role: user.role,
      userID: user._id
    }, "rahmadassemdawi");
    console.log("Generated Token:", token);
    res.json({ message: "Welcome to Post App", token });
  }
  
};

