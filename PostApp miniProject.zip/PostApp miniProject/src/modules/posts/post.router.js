import express from "express";
import { addPost, deletePost, getAllPosts, updatePost,getUserPosts } from "./post.controller.js";
import { verifyToken } from "../../middleware/auth.js";

const postRouter=express.Router();
postRouter.post("/",verifyToken,addPost)
postRouter.get("/",verifyToken,getAllPosts)
postRouter.put("/",verifyToken,updatePost)
postRouter.delete("/",verifyToken,deletePost)
postRouter.get("/getUserPosts/:userId",verifyToken, getUserPosts);
export default postRouter
