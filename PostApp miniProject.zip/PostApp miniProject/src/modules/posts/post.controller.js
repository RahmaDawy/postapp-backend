import { postModel } from "../../../database/models/post.model.js";
import jwt from "jsonwebtoken"
// Add a new post
export const addPost = async (req, res) => {
    try {
      const { title, desc, createdBy } = req.body;
      const newPost = await postModel.create({ title, desc, createdBy:req.userId });
      res.json({ message: "Post added successfully", newPost });  
    } catch (error) {
      res.status(500).json({ message: "Error adding post", error });
    }
  };
  
  // Get all posts
  export const getAllPosts = async (req, res) => {
    try {
      const posts = await postModel.find().populate("createdBy");
      res.json({ message: "success", posts });  
    } catch (error) {
      res.status(500).json({ message: "Error fetching posts", error });
    }
  };
  export const getUserPosts = async (req, res) => {
    const { userId } = req.params;
    try {
      const posts = await postModel.find({ createdBy: userId }).populate("createdBy", "name -_id");
      res.json({ message: "success", posts });
    } catch (error) {
      res.status(500).json({ message: "Error fetching user posts", error });
    }
  };
  
  

// Update a post
export const updatePost = async (req, res) => {
  try {
    const { _id, title, desc } = req.body;
    const post = await postModel.findByIdAndUpdate(
      _id,
      { title, desc },
      { new: true }
    );

    if (post) {
      res.json({ message: "success", post });
    } else {
      res.status(404).json({ message: "Post not found" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error updating post", error });
  }
};

// Delete a post
export const deletePost = async (req, res) => {
  try {
    const { _id } = req.body;
    const post = await postModel.findByIdAndDelete(_id);

    if (post) {
      res.json({ message: "success", post });
    } else {
      res.status(404).json({ message: "Post not found" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error deleting post", error });
  }
};
