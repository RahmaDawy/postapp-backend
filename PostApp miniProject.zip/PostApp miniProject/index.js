import express from "express";
import userRouter from "./src/modules/user/user.router.js";
import postRouter from "./src/modules/posts/post.router.js";
import { dbConnection } from "./database/dbConnection.js";
import cors from 'cors';



const app = express();
app.use(express.json());

dbConnection();

const port = 3000;
app.use(cors());

app.use("/posts", postRouter);
app.use("/users", userRouter);

app.listen(port, () => console.log(`Example app listening on port ${port}!`));
